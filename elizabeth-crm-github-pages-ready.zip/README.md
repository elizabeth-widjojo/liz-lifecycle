# Elizabeth Widjojo — CRM & Lifecycle Growth Consulting

Production-ready, single-page static site designed for GitHub Pages. No build tool, framework, package installation, or external services are required.

## Deploy to the existing GitHub Pages site

1. Open the repository: `https://github.com/elizabeth-widjojo/elizabeth-widjojo.github.io`.
2. Back up the existing `index.html` before replacing it.
3. Upload the **contents** of this folder (not the folder itself) to the repository root on `main`: `index.html`, `favicon.svg`, `social-preview.png`, `robots.txt`, `sitemap.xml`, and `.nojekyll`.
4. **Remove the old PDF resume and any unused assets from the published branch**, if you do not want them publicly accessible on GitHub Pages. Do not copy the old resume into the new deployment.
5. Commit the changes. GitHub Pages should serve the new page at `https://elizabeth-widjojo.github.io/` after deployment completes.
6. Check **Settings → Pages** if the site does not update; confirm the source points to the root of the relevant branch.
7. Test navigation, expandable case-study details, mobile layout, and the email enquiry links on the published URL.

## Editable site details

All text and styling are in `index.html`; no build process is needed.

- Display name / branding: search for `Elizabeth Widjojo`.
- Contact address: search for `elizabethwidjojo@gmail.com` (appears in both mail links).
- Colors: modify the CSS variables under `:root`.
- Content: update the `#services`, `#work`, `#engagements`, and `#about` sections.
- Social card: replace `social-preview.png` if you change the main headline.
- Canonical URL: if you later move to a custom domain, change the canonical, Open Graph URL/image, `robots.txt`, and `sitemap.xml`.

## Publication and confidentiality checks

The site **does not display previous or current employer names, logos, job titles, work dates, named initiatives, or employer-facing resume links**. Case studies are labelled as experience from in-house roles, *not* prior consulting-client work.

Before making this public, decide whether historical numerical outcomes may be disclosed under any applicable confidentiality obligations. Removing company names does not fully anonymize a case study: a distinctive outcome, technology, or business context may still be recognizable. If needed, replace case-study metrics with approved ranges or qualitative wording.

The old GitHub commits and publicly cached pages may still contain identifiable information even if you replace the current files. Deleting a PDF from the branch removes it from the live site, but not necessarily from git history. If strict separation is required, consider a new repository/account/domain and GitHub's history-removal guidance rather than assuming this update erases past records.

## Design choices

- Option B's card-led, high-contrast layout, refined with cleaner spacing and typography.
- Full site works without JavaScript except for the footer's current year (it gracefully defaults to 2026).
- Accessible anchor navigation, skip link, keyboard-operable native expandable case studies, and reduced-motion support.
- No analytics, trackers, cookies, embedded forms, remote fonts, or client data collection.
- Working `mailto:` calls to action. A scheduling widget or contact form is intentionally not configured because no booking URL or form provider was supplied.

## File list

- `index.html` — website (embedded CSS and minimal JavaScript)
- `favicon.svg` — favicon
- `social-preview.png` — social sharing thumbnail
- `robots.txt` — crawler instructions
- `sitemap.xml` — sitemap
- `.nojekyll` — disable Jekyll processing
